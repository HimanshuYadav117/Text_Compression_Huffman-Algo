#define MAX 16
//padding each character to fit byte size

char padding;
unsigned char N;


//Creating the CodeTable
typedef struct codeTable
{
    char x;
    char code[MAX];
} codeTable;

char compressed_extension[]  = ".sha";
char decompressed_extension[] = ".txt";


